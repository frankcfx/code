package com.ibeifeng.senior.usertrack.spark

/**
  * NOTE：该package的内容主要是对于热门商品进行分析统计
  * Created by ibf on 03/06.
  */
package object product {

}

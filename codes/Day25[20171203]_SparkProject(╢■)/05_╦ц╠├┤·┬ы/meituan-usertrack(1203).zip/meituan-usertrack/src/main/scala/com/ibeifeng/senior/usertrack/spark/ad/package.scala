package com.ibeifeng.senior.usertrack.spark

/**
  * NOTE: 该package中的内容主要是用于对实时广告点击进行统计分析
  * Created by ibf on 03/06.
  */
package object ad {

}

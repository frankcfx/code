package com.ibeifeng.senior.scala

import java.io.IOException

import scala.util.{Failure, Success, Try}


/**
  * Created by ibf on 11/12.
  */
object PatternDemo {
  /**
    * 匹配的时候，从上往下进行条件匹配，所以一般情况下将限制比较严格的条件放到前面
    *
    * @param n
    */
  def f1(n: Int): Unit = {
    n match {
      case 1 => {
        println("value == 1")
      }
      case 2 => {
        println("value == 2")
      }
      /*case e => {
        // 表示匹配任意值，并且e的值即为n的值
        println(s"other:${e}")
      }*/
      case _ => {
        // 下划线表示匹配所有，并且匹配值不需要使用
        println(s"other:${n}")
      }
    }
  }

  def f2(throwable: Throwable): Unit = {
    throwable match {
      case e: IOException => {
        // 仅仅匹配类型为IO的异常
        println(s"io:${e.getMessage}")
      }
      case _: IllegalArgumentException => {
        println(s"argument error:${throwable.getMessage}")
      }
      case e: RuntimeException => {
        println(s"runtime:${e.getMessage}")
      }
      case _ => {
        println(s"other error:${throwable.getMessage}")
      }
    }
  }

  // 多匹配的变量绑定
  def f3(throwable: Throwable): Unit = {
    throwable match {
      case e: IOException => {
        // 仅仅匹配类型为IO的异常
        println(s"io:${e.getMessage}")
      }
      case e@(_: IllegalArgumentException | _: ArithmeticException) => {
        println(s"argument error:${e.getMessage}")
      }
      case e: RuntimeException => {
        println(s"runtime:${e.getMessage}")
      }
      case _ => {
        println(s"other error:${throwable.getMessage}")
      }
    }
  }

  // 递归实现 ==> 有模式匹配
  def f4(list: List[Int]): Int = {
    list match {
      case Nil => 0
      case head :: Nil => head
      case head :: tail => head + f4(tail)
    }
  }

  def f5(list: List[Int]): Int = {
    list match {
      case Nil => 0
      case head :: Nil => {
        throw new RuntimeException
      }
      case head :: tail => head + f5(tail)
    }
  }

  /**
    * 递归的问题：每次递归，均会将调用放到栈中，当递归的层次比较多的时候，就会出现栈溢出
    * 优化: 尾递归优化 ==> 可以解决递归的栈溢出问题，仅仅使用一个栈内存进行计算；要求：返回值中不能有表达式，只能是递归函数调用或者是最终结果
    */
  def f6(list: List[Int], sum: Int = 0): Int = {
    list match {
      case Nil => sum
      case head :: Nil => {
        // head + sum
        throw new RuntimeException
      }
      case head :: tail => f6(tail, sum + head)
    }
  }


  case class Student(name: String, age: Int, sex: String)

  def f7(student: Student): Unit = {
    student match {
      case Student("gerry", _, "M") => {
        println("gerry")
      }
      case Student(_, age, _) if age % 2 == 0 => {
        println(s"age=${age}")
      }
      case Student(name, age, sex) => {
        println(s"name=${name}, age=${age}, sex=${sex}")
      }
    }
  }

  def main(args: Array[String]): Unit = {
    val map = Map("abc" -> 123, "def" -> 34)

    val option: Option[Int] = map.get("abc")
    if (option.isEmpty) {
      // 表示为None
    }
    if (option.isDefined) {
      // 表示为Some
      println(s"value=${option.get}")
    }
    println(s"有值就获取，没有值就返回默认值:${option.getOrElse(-1)}")
    option match {
      case Some(v) => {
        println(s"value为:${v}")
      }
      case None => {
        println("没有对应的值")
      }
    }

    // option的API
    option.map(v => v * 2) // 当option为Some的时候，对Some中的值进行乘以2的操作
    option.orElse {
      // 当option为None的时候执行else部分的语句块
      Some("")
    }.get

    // 异常处理
    try {
      println("try 1")
      3 / 0
      println("try 2")
    } catch {
      case e: IOException => {
        println("io error")
      }
      case e: Throwable => f3(e)
    } finally {
      println("f1")
    }

    // scala提供了一个对象:Try方便进行异常的管理
    val t: Try[Double] = Try {
      println("Try 1")
      val result: Int = 3 / 0
      println("Try 2")
      // 返回值
      result.toDouble
    }
    println(t.isSuccess)
    println(t.isFailure)

    t match {
      case Success(result) => {
        println(s"result=${result}")
      }
      case Failure(exception) => {
        f3(exception)
      }
    }

  }

}

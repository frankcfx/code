package com.ibeifeng.senior.scala

/**
  * Created by ibf on 11/12.
  */
class Person private(val name: String, var age: Int = 28) {
  println("init......")
  private var v1 = 1000
  private[this] var v2 = Person.V
  //  private[scala] var v3 = 10000
  var v3 = 10000

  try {
    println("init......")
  } finally {
    println("close.....")
  }

  def this() {
    this("gerry", 19)
  }

  def this(age: Int) {
    this("gerry", age)
    //    this()
    //    this.age = age
  }

  def this(name: String, age: Int, sex: String) {
    this(age)
  }


  def addAge(): Unit = {
    this.age += 1
  }

  def watch: Unit = {
    println(s"${name} watch ....")
  }

  def f(other: Person): Unit = {
    println(s"当前对象值:${v1}, ${v2}, ${v3}")
    // other.v2是没法访问的，因为v2这个变量只能在当前对象中访问
    // println(s"传入的对象值:${other.v1}, ${other.v2}, ${other.v3}")
    println(s"传入的对象值:${other.v1}, ${other.v3}")
  }

  override def toString = s"Person($name, $age)"

  println("end......")
}

object Person {
  private val V = 123456
  val V1 = 456

  def apply(name: String): Student = new Student(name)

  def main(args: Array[String]): Unit = {
    val person = new Person("gerry", 18)
    println(person.v1)
  }
}

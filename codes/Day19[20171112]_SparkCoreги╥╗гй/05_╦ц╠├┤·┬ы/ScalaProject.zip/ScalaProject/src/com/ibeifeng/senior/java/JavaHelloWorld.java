package com.ibeifeng.senior.java;

/**
 * Created by ibf on 11/12.
 */
public class JavaHelloWorld {
    public static void main(String[] args) {
        System.out.println("hello");
    }
}
